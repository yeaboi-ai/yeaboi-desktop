# @yeaboi-ai/design

The design system behind [yeaboi](https://yeaboi.ai)'s browser surfaces — tokens, palettes and
primitives. Published as **source**, not a build: consumers compile it with their own bundler, which
is what keeps the desktop app and the web boards drawing from one compiler rather than two.

Generated from [yeaboi-frontend](https://github.com/yeaboi-ai/yeaboi-frontend) by
`scripts/pack-design.mjs`. Do not edit here — edit there.

Resolve it through a bundler alias rather than by package name:

```ts
'@design': resolve('node_modules/@yeaboi-ai/design/design')
```

It imports `react`, which every consumer aliases to `preact/compat`.
