/**
 * A loading placeholder that holds the shape of what is coming.
 *
 * The alternative it replaces is the literal string "Loading…", which reflows
 * the whole page when the data lands. A skeleton reserves the space — the same
 * reserve-don't-reflow principle the TUI applies to its description rows — and
 * the sweep says "working" without a spinner.
 *
 * `aria-hidden`: the loading state is announced by the surface that owns the
 * fetch, not by each placeholder block.
 */

import type { CSSProperties } from 'react';

import { cx } from '../../runtime/cx';
import styles from './primitives.module.css';

export interface SkeletonProps {
  /** `line` holds a text row, `block` a card, `stat` a stat tile. */
  variant?: 'line' | 'block' | 'stat';
  /** Length/height overrides, e.g. "12ch" or 96. */
  width?: string | number;
  height?: string | number;
  className?: string | undefined;
}

const VARIANTS = { line: 'skeletonLine', block: 'skeletonBlock', stat: 'skeletonStat' } as const;

export function Skeleton({ variant = 'line', width, height, className }: SkeletonProps) {
  const style: CSSProperties = {};
  if (width !== undefined) style.width = typeof width === 'number' ? `${width}px` : width;
  if (height !== undefined) style.height = typeof height === 'number' ? `${height}px` : height;
  return (
    <span
      aria-hidden="true"
      className={cx(styles['skeleton'], styles[VARIANTS[variant]], className)}
      style={style}
    />
  );
}
