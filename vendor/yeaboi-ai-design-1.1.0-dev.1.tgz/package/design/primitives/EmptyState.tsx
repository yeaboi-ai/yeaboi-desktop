/**
 * An empty screen is an invitation to act, delivered by the duck.
 *
 * One title says what there is none of; one hint says how the first one comes
 * to exist; an optional action is the way to do it right here. The duck is the
 * brand's own way of saying "nothing is wrong" — an empty list with no
 * furniture at all reads as a failed fetch.
 */

import type { ReactNode } from 'react';

import { cx } from '../../runtime/cx';
import { Duck } from './Duck';
import styles from './primitives.module.css';

export interface EmptyStateProps {
  title: string;
  /** How the first item comes to exist. */
  hint?: ReactNode;
  /** The control that creates it, rendered under the hint. */
  action?: ReactNode;
  className?: string | undefined;
}

export function EmptyState({ title, hint, action, className }: EmptyStateProps) {
  return (
    <div className={cx(styles['empty'], className)}>
      <Duck state="idle" size={44} />
      <p className={styles['emptyTitle']}>{title}</p>
      {hint ? <p className={styles['emptyHint']}>{hint}</p> : null}
      {action}
    </div>
  );
}
