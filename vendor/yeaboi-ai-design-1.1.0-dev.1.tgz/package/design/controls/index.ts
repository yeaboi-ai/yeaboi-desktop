/**
 * The control vocabulary the desktop shares with the boards.
 *
 * These are the `src/shared/` components, published: re-exported from here so
 * the pack closure (rooted at `src/design/`) carries them, while the boards
 * keep importing from `../shared/` untouched. The files themselves do not
 * move — `shared.module.css` is one module on purpose (its class names are
 * cross-referenced by attribute selectors like `[data-edge] .iconLabel`), and
 * splitting it would fork those references.
 */

export {
  Button,
  buttonClass,
  type ButtonProps,
  type ButtonShape,
  type ButtonSize,
  type ButtonTone,
} from '../../shared/Button';
export { IconButton, type IconButtonProps } from '../../shared/IconButton';
export { Modal, type ModalProps } from '../../shared/Modal';
export { ThemeSwitcher, type ThemeSwitcherProps } from '../../shared/ThemeSwitcher';
export { Field, TextArea, TextInput, type FieldProps } from './Field';
