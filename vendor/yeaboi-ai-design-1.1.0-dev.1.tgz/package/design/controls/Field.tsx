/**
 * The label-over-control form grammar, as a component.
 *
 * The boards already settled this grammar in `shared.module.css` (`.field`,
 * `.fieldLabel`, `.textInput`): fields stack, a mono uppercase label sits above
 * its control, hints sit under it. This wraps that settled vocabulary so a
 * consumer builds a form out of one component instead of remembering four
 * class names — and so the label is a real `<label>`, wired to the control by
 * containment rather than by ids nobody keeps unique.
 */

import { forwardRef, type ComponentProps, type ReactNode } from 'react';

import { cx } from '../../runtime/cx';
import shared from '../../shared/shared.module.css';
import styles from './controls.module.css';

export interface FieldProps {
  label: string;
  /** One grey line under the control — a format example, a consequence. */
  hint?: ReactNode;
  /** Replaces the hint and is announced: what went wrong and how to fix it. */
  error?: ReactNode;
  children: ReactNode;
  className?: string | undefined;
}

export function Field({ label, hint, error, children, className }: FieldProps) {
  return (
    <label className={cx(shared['field'], className)}>
      <span className={shared['fieldLabel']}>{label}</span>
      {children}
      {error ? (
        <span role="alert" className={styles['fieldError']}>
          {error}
        </span>
      ) : hint ? (
        <span className={styles['fieldHint']}>{hint}</span>
      ) : null}
    </label>
  );
}

export interface TextInputProps
  // `className` re-declared for the same preact `Signalish` reason as Button.
  extends Omit<ComponentProps<'input'>, 'className'> {
  className?: string | undefined;
}

export const TextInput = forwardRef<HTMLInputElement, TextInputProps>(function TextInput(
  { className, type = 'text', ...rest },
  ref,
) {
  return <input {...rest} ref={ref} type={type} className={cx(shared['textInput'], className)} />;
});

export interface TextAreaProps extends Omit<ComponentProps<'textarea'>, 'className'> {
  className?: string | undefined;
}

export const TextArea = forwardRef<HTMLTextAreaElement, TextAreaProps>(function TextArea(
  { className, ...rest },
  ref,
) {
  return (
    <textarea
      {...rest}
      ref={ref}
      className={cx(shared['textInput'], styles['textArea'], className)}
    />
  );
});
